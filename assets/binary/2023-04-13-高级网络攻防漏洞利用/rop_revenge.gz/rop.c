// gcc rop.c -fno-stack-protector -no-pie -o rop
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <linux/seccomp.h>
#include <sys/prctl.h>
#include <string.h>

int initial;

static void install_seccomp() {
  static unsigned char filter[] = {32,0,0,0,4,0,0,0,21,0,0,12,62,0,0,192,32,0,0,0,0,0,0,0,53,0,10,0,0,0,0,64,21,0,8,0,2,0,0,0,21,0,7,0,1,1,0,0,21,0,6,0,181,1,0,0,21,0,5,0,0,0,0,0,21,0,4,0,1,0,0,0,21,0,3,0,3,0,0,0,21,0,2,0,60,0,0,0,21,0,1,0,231,0,0,0,6,0,0,0,5,0,5,0,6,0,0,0,0,0,255,127,6,0,0,0,0,0,0,0};
  struct prog {
    unsigned short len;
    unsigned char *filter;
  } rule = {
    .len = sizeof(filter) >> 3,
    .filter = filter
  };
  if(prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) < 0) { perror("prctl(PR_SET_NO_NEW_PRIVS)"); _exit(2); }
  if(prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &rule) < 0) { perror("prctl(PR_SET_SECCOMP)"); _exit(2); }
}

void some_gifts() {
    int fd = open("./gifts.txt", O_RDONLY);
    _exit(0);
}

void vuln() {
    char buf[0x100];
    if (initial++ > 0) {
        _exit(1);
    }
    read(0, buf, 0x110);
}

int main() {
    int choice = -1;
    install_seccomp();
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    write(1, "Welcome to the Santa's gift!\n", 29);
    write(1, "your choice:\n", 13);
    scanf("%d", &choice);
    switch (choice)
    {
    case 0x1337:
        vuln();
        break;
    
    case 0x2333:
        some_gifts();
        break;
    
    default:
        _exit(1);
    }
    _exit(0);
}