<?php
include("closure/autoload.php");
function myloader($class){
    require_once './class/' . (str_replace('\\', '/', $class) . '.php');
}
spl_autoload_register("myloader"); 
error_reporting(0);
if($_POST['data']){
	$vvvccc=base64_decode($_POST['data']);
	//print_r($vvvccc);
	if(preg_match("/ob_start|shell_exec|exec|system|passthru|print|print_r|var_dump|bash|tac|nl|more|less|head|wget|tail|vi|cat|grep|sed|bzmore|bzless|pcre|paste|diff|sh/i", $vvvccc)){
            echo("easy yii!");
            echo "<br>";
			exit;
        }
    unserialize($vvvccc);
}else{
	echo "<h1>easy yii!</h1>";
}