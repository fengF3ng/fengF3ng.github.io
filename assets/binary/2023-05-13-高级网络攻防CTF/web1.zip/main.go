package main

import (
	"html/template"
	"log"
	"net/http"
	"os"
	"strings"
)

type User struct {
	Name string
	Age  int
}

func (u *User) GetFlag(key string) string {
	if key == "give_me_flag" {
		return os.Getenv("FLAG")
	} else {
		return "try harder"
	}
}

func userPage(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	data := &User{"NeSE", 10}
	tmplStr := "<p>hello {{.Name}}, your age is: {{.Age}}</p>"

	if r.Form.Get("tmpl") != "" && !strings.Contains(r.Form.Get("tmpl"), "give_me_flag") {
		tmplStr = r.Form.Get("tmpl")
	}
	tmpl, err := template.New("example").Parse(tmplStr)
	if err != nil {
		log.Printf("Parse: %v", err)
		return
	}
	err = tmpl.Execute(w, data)
	if err != nil {
		log.Printf("Execute: %v", err)
	}
}

func main() {
	server := http.Server{
		Addr: "0.0.0.0:8001",
	}

	http.HandleFunc("/", userPage)
	log.Println("Server started")
	server.ListenAndServe()
}
